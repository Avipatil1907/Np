﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ass2.Models;  
namespace ass2.Controllers
{
    public class homeController : Controller
    {
        //
        // GET: /home/

        public ActionResult Index()
        {
            var data = GetEmployee();
            return View(data); 
        }
        private Employee GetEmployee()
        {
            return new Employee()
            {
                id = 1,
                Address = "India",
                Name = "RCP",
            };
        } 

    }
}
