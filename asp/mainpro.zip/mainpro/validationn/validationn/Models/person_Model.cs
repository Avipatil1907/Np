﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace validationn.Models
{
    public class person_Model
    {
        [Required(ErrorMessage = "Name is required.")]
        public string Name { get; set; }

          [Required(ErrorMessage = "Age is required.")]
        [Range(18,100,ErrorMessage="Age must be between 18 and 100.")]
          public string Age{ get; set; }

    
          [Required(ErrorMessage = "Contact number is required.")]
        [Phone(ErrorMessage="invalid contact number.")]
        [StringLength(10,ErrorMessage="Contact number must be exactly 10 didgits.",MinimumLength=10)]
          public string Contact { get; set; }

    
        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage="invalid email format.")]
        public string Email { get; set; }



        [Required(ErrorMessage = "Address is required.")]
        public string Address { get; set; }

    }
}